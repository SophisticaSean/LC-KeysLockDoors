# KeysLockDoors
Adds a feature to all keys that lets them lock doors. Lock up enemies! Lock up friends! :)
Simply put a key in your hand and hit E to lock a closed door!
