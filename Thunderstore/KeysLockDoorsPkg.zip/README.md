# KeysLockDoors
Adds a feature to all keys that lets them lock doors. Lock up enemies! Lock up friends! :)
Simply put a key in your hand and hit LMB to lock a closed door (same button as unlocking a door)!
